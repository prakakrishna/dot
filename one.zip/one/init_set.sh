#!/bin/bash
echo "sleeping for 60 seconds"
sleep 60

echo init_set.sh time now: `date +"%T"`

while [ 1 ]
do
  mysql -h mariadb-master -e "show databases;" >/dev/null
  [[ $? -ne 0 ]] && echo "Waiting for mariadb-master to start" && sleep 30 || break
done

while [ 1 ]
do
  mysql -h mariadb-slave1 -e "show databases;" >/dev/null
  [[ $? -ne 0 ]] && echo "Waiting for mariadb-slave1 to start" && sleep 30 || break
done

while [ 1 ]
do
  mysql -h mariadb-slave2 -e "show databases;" >/dev/null
  [[ $? -ne 0 ]] && echo "Waiting for mariadb-slave2 to start" && sleep 30 || break
done

read -r file postion <<< `mysql -h mariadb-master -e "show master status;" | grep master`

[[ ! -f /data/dump.sql ]] && mysql -h mariadb-master <<EOF
STOP SLAVE;
CREATE USER 'replication_user'@'%' IDENTIFIED BY 'password';
GRANT REPLICATION SLAVE ON *.* TO 'replication_user'@'%';
FLUSH TABLES WITH READ LOCK;
EOF

[[ ! -f /data/dump.sql ]] && mysql -h mariadb-slave1 <<EOF
CREATE USER 'replication_user'@'%' IDENTIFIED BY 'password';
GRANT REPLICATION SLAVE ON *.* TO 'replication_user'@'%';
EOF

[[ ! -f /data/dump.sql ]] && mysql -h mariadb-slave2 <<EOF
CREATE USER 'replication_user'@'%' IDENTIFIED BY 'password';
GRANT REPLICATION SLAVE ON *.* TO 'replication_user'@'%';
EOF

[[ ! -f /data/dump.sql ]] && read -r file postion <<< `mysql -h mariadb-master -e "show master status;" | grep master` && mysqldump --all-databases -h mariadb-master -u root --master-data > /data/dump.sql && mysql -h mariadb-master -e "unlock tables;"

[[ -f /data/dump.sql && -z `mysql -h mariadb-slave1 -e "SHOW SLAVE STATUS\G;" | grep Slave_IO_State | cut -d: -f2 | sed 's/ //g'` ]] && mysql -h mariadb-slave1 < /data/dump.sql && mysql -h mariadb-slave1 <<EOF
CHANGE MASTER TO
  MASTER_HOST='mariadb-master',
  MASTER_USER='replication_user',
  MASTER_PASSWORD='password',
  MASTER_PORT=3306,
  MASTER_LOG_FILE="$file",
  MASTER_LOG_POS=$postion,
  MASTER_CONNECT_RETRY=10;
START SLAVE;
EOF

[[ -f /data/dump.sql && -z `mysql -h mariadb-slave2 -e "SHOW SLAVE STATUS\G;" | grep Slave_IO_State | cut -d: -f2 | sed 's/ //g'` ]] && mysql -h mariadb-slave2 < /data/dump.sql && mysql -h mariadb-slave2 <<EOF
CHANGE MASTER TO
  MASTER_HOST='mariadb-master',
  MASTER_USER='replication_user',
  MASTER_PASSWORD='password',
  MASTER_PORT=3306,
  MASTER_LOG_FILE="$file",
  MASTER_LOG_POS=$postion,
  MASTER_CONNECT_RETRY=10;
START SLAVE;
EOF

echo "Done"
